import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseStamped
from rc import SetInitialPose, SetGoalPose  # Import the service messages
import serial
import time

# ... (the rest of your code remains the same)

def set_initial_pose_client(pose):
    rospy.wait_for_service('/set_initial_pose')  # Wait for the service to become available
    try:
        set_initial_pose = rospy.ServiceProxy('/set_initial_pose', SetInitialPose)
        response = set_initial_pose(pose)
        return response
    except rospy.ServiceException as e:
        rospy.logerr("Service call to set_initial_pose failed: %s" % str(e))

def set_goal_pose_client(pose):
    rospy.wait_for_service('/set_goal_pose')  # Wait for the service to become available
    try:
        set_goal_pose = rospy.ServiceProxy('/set_goal_pose', SetGoalPose)
        response = set_goal_pose(pose)
        return response
    except rospy.ServiceException as e:
        rospy.logerr("Service call to set_goal_pose failed: %s" % str(e)

# ... (the rest of your code remains the same)

if __name__ == '__main__':
    try:
        # Initialize the ROS node
        rospy.init_node('hector_simulator')

        # Subscribe to the LaserScan topic
        rospy.Subscriber('/scan', LaserScan, laser_scan_callback)

        # Set the initial and goal poses
        initial_pose = PoseWithCovarianceStamped()  # Create an initial pose message
        goal_pose = PoseStamped()  # Create a goal pose message

        # Example: Set the initial pose to (1.0, 1.0, 0.0)
        initial_pose.pose.pose.position.x = 1.0
        initial_pose.pose.pose.position.y = 1.0
        initial_pose.pose.pose.position.z = 0.0

        # Example: Set the goal pose to (3.0, 2.0, 0.0)
        goal_pose.pose.position.x = 3.0
        goal_pose.pose.position.y = 2.0
        goal_pose.pose.position.z = 0.0

        # Call the services to set the initial and goal poses
        set_initial_pose_client(initial_pose)
        set_goal_pose_client(goal_pose)

        # Start publishing PoseStamped data
        publish_laser_scan()

        # Spin to process callbacks
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
