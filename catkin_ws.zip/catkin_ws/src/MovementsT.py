import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseStamped
import serial
import time

# Define the serial port of the Arduino
arduino_port = '/dev/ttyACM0'
baud_rate = 9600

# Initialize the serial connection to the Arduino
ser = serial.Serial(arduino_port, baud_rate)

# Define the angle range for detection
angle_min = 0
angle_max = 120

# Define the distance threshold for detection (in centimeters)
distance_threshold = 65.0 

def laser_scan_callback(scan):
    # Check if an object is detected within the specified angle range and distance
    for i, angle in enumerate(scan.ranges):
        if angle_min <= i < angle_max and angle * 100 <= distance_threshold:
            rospy.loginfo("Object detected within range (320-360 degrees) and 45 cm away. Sending 'r' to Arduino.")
            ser.write(b'r')  # Send 'r' to the Arduino
            return

    # If no object is detected, send 'g' to the Arduino
    ser.write(b'g')

def publish_laser_scan():
    # Create a ROS node
    rospy.init_node('hector_simulator')

    # Create a publisher for simulated pose data
    pose_publisher = rospy.Publisher('/hector_pose_estimate', PoseStamped, queue_size=1)

    # Set the publishing rate
    rate = rospy.Rate(10)  # 10 Hz

    while not rospy.is_shutdown():
        # Simulate a PoseStamped message
        pose = PoseStamped()
        pose.header.stamp = rospy.Time.now()
        pose.header.frame_id = 'base_link'  # Set the appropriate frame ID
        pose.pose.position.x = 1.0  # Simulated position
        pose.pose.position.y = 1.0
        pose.pose.position.z = 0.0
        pose.pose.orientation.x = 0.0  # Simulated orientation
        pose.pose.orientation.y = 0.0
        pose.pose.orientation.z = 0.0
        pose.pose.orientation.w = 1.0

        # Publish the simulated PoseStamped data
        pose_publisher.publish(pose)

        rate.sleep()

if __name__ == '__main__':
    try:
        # Initialize the ROS node
        rospy.init_node('hector_simulator')

        # Subscribe to the LaserScan topic
        rospy.Subscriber('/scan', LaserScan, laser_scan_callback)

        # Start publishing PoseStamped data
        publish_laser_scan()

        # Spin to process callbacks
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
