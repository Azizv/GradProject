
"use strict";

let ResetMapping = require('./ResetMapping.js')

module.exports = {
  ResetMapping: ResetMapping,
};
